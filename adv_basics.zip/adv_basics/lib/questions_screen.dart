import 'package:adv_basics/answer_button.dart';
import 'package:adv_basics/data/questions.dart';
import 'package:flutter/material.dart';

class QuestionsScreen extends StatefulWidget {
  const QuestionsScreen({super.key, required this.chooseAnswer});

  final void Function(String answer, BuildContext ctx) chooseAnswer;

  @override
  State<QuestionsScreen> createState() {
    // TODO: implement createState
    return _QuestionsState();
  }
}

class _QuestionsState extends State<QuestionsScreen> {
  var indexQuestion = 0;

  void nextQuestion(String answer, BuildContext ctx) {
    setState(() {
      if (indexQuestion <= questions.length - 1) {
        indexQuestion += 1;
        widget.chooseAnswer(answer, ctx);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    final currentQuestion = questions[indexQuestion];

    return Center(
      child: Container(
        margin: const EdgeInsets.only(left: 10, right: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              currentQuestion.text,
              style: const TextStyle(color: Colors.white, fontSize: 20),
              textAlign: TextAlign.center,
            ),
            const SizedBox(
              height: 20,
            ),
            ...currentQuestion.answers.map((item) {
              return AnswerButton(
                  label: item,
                  onPress: () {
                    nextQuestion(item, context);
                  });
            })
          ],
        ),
      ),
    );
  }
}
