import 'package:adv_basics/model/quiz_question.dart';

const questions = [
  QuizQuestion("Q1", ["A1", "B1", "C1", "D1"]),
  QuizQuestion("Q2", ["A2", "B2", "C2", "D2"]),
  QuizQuestion("Q3", ["A3", "B3", "C3", "D3"]),
  QuizQuestion("Q4", ["A4", "B4", "C4", "D4"]),
  QuizQuestion("Q5", ["A5", "B5", "C5", "D5"])
];
