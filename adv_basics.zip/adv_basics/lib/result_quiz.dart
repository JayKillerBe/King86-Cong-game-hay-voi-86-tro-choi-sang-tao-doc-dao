import 'package:adv_basics/data/questions.dart';
import 'package:flutter/material.dart';

class ResultQuizScreen extends StatefulWidget {
  const ResultQuizScreen({super.key, required this.results});

  final List<String> results;
  List<Map<String, Object>> getSummaryData() {
    final List<Map<String, Object>> summary = [];
    for (var i = 0; i < results.length; i++) {
      summary.add({"asdasd": 3});
    }
    return summary;
  }

  @override
  State<ResultQuizScreen> createState() {
    return _ResultQuizState();
  }
}

class _ResultQuizState extends State<ResultQuizScreen> {
  @override
  Widget build(BuildContext context) {
    var idx = 0;

    return Text("Some Screen");

    return Column(
      children: [
        ...widget.results.map((item) {
          final question = questions[idx].text;
          idx++;
          return Column(
            children: [
              Text(
                "Question: $question",
                style: TextStyle(fontSize: 20),
              ),
              Text(
                "Answer: $item",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15),
              ),
              SizedBox(
                height: 20,
              )
            ],
          );
        })
      ],
    );
  }
}
