import 'package:flutter/material.dart';

class StartScreen extends StatelessWidget {
  const StartScreen(this.startQuizz, {super.key});

  final void Function() startQuizz;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Image.asset(
            "assets/images/shiba-inu.png",
            width: 150,
            color: const Color.fromARGB(255, 255, 254, 254),
          ),
          // Opacity(
          //   opacity: 0.5,
          //   child: Image.asset(
          //     "assets/images/shiba-inu.png",
          //     width: 150,
          //   ),
          // ),
          const SizedBox(
            height: 20,
          ),
          const Center(
            child: Text(
              "Quiz App",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
              ),
            ),
          ),
          const SizedBox(
            height: 50,
          ),
          OutlinedButton.icon(
            onPressed: startQuizz,
            style: ElevatedButton.styleFrom(
              foregroundColor: const Color.fromARGB(255, 255, 255, 255),
            ),
            icon: const Icon(Icons.arrow_right_alt),
            label: const Text("Start Quiz"),
          )
        ],
      ),
    );
  }
}
